<?php
require_once __DIR__ . '/includes/functions.php';


$pageTitle   = APP_NOMBRE . ' | Inicio';
$destacados  = lugares_destacados(8);
$conteos     = conteo_dashboard();
$placesJson  = json_encode($destacados, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

require_once __DIR__ . '/includes/header.php';
?>

<section class="hero-section">
    <div class="container py-5">
        <div class="row align-items-center g-5 py-4">

            <!-- TEXTO -->
            <div class="col-lg-6">
                <span class="badge badge-soft mb-3">
                    Turismo inteligente en Colombia
                </span>

                <h1 class="display-5 fw-bold mb-3">
                    Descubre ciudades, sitios y experiencias con una plataforma profesional.
                </h1>

                <p class="lead text-muted mb-4">
                    Explora lugares destacados, consulta el mapa, compara calificaciones y administra contenido con seguridad.
                    Sí, por fin un sitio que no parece hecho en un descanso de cinco minutos.
                </p>

                <div class="d-flex flex-wrap gap-2">
                    <a href="#destacados" class="btn btn-orange btn-lg">
                        <i class="fa-solid fa-mountain-sun me-2"></i>Ver sitios
                    </a>

                    <?php if (!usuario_autenticado()): ?>
                        <a href="<?= e(url('register.php')) ?>" class="btn btn-outline-dark btn-lg">
                            Crear cuenta
                        </a>
                    <?php else: ?>
                        <a href="<?= e(url('dashboard.php')) ?>" class="btn btn-outline-dark btn-lg">
                            Ir al dashboard
                        </a>
                    <?php endif; ?>
                </div>

                <div class="d-flex gap-4 mt-4 text-muted small flex-wrap">
                    <div>
                        <i class="fa-solid fa-user-group text-orange me-1"></i>
                        <?= (int)$conteos['usuarios'] ?> usuarios
                    </div>

                    <div>
                        <i class="fa-solid fa-location-dot text-orange me-1"></i>
                        <?= (int)$conteos['sitios'] ?> sitios
                    </div>

                    <div>
                        <i class="fa-solid fa-comment text-orange me-1"></i>
                        <?= (int)$conteos['comentarios'] ?> comentarios
                    </div>
                </div>
            </div>

            <!-- MAPA -->
            <div class="col-lg-6">
                <div class="hero-card shadow-lg">
                    <div class="hero-card-top d-flex justify-content-between align-items-center mb-3">
                        <span class="fw-semibold">Mapa turístico</span>
                        <span class="text-muted small">Colombia</span>
                    </div>

                    <div id="mapa" class="mapa-home"></div>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- FEATURES -->
<section class="py-5 bg-white">
    <div class="container">
        <div class="row g-4 text-center">

            <div class="col-md-4">
                <div class="feature-card h-100">
                    <i class="fa-solid fa-shield-halved feature-icon"></i>
                    <h5 class="mt-3">Acceso seguro</h5>
                    <p class="text-muted mb-0">
                        Sesiones, hashes y validaciones para usuarios y administradores.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="feature-card h-100">
                    <i class="fa-solid fa-map-location-dot feature-icon"></i>
                    <h5 class="mt-3">Mapa integrado</h5>
                    <p class="text-muted mb-0">
                        Sitios destacados con coordenadas y visualización interactiva.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="feature-card h-100">
                    <i class="fa-solid fa-star feature-icon"></i>
                    <h5 class="mt-3">Experiencia turística</h5>
                    <p class="text-muted mb-0">
                        Diseño limpio, móvil primero y visual coherente en toda la app.
                    </p>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- DESTACADOS -->
<section id="destacados" class="py-5 bg-light">
    <div class="container">

        <div class="d-flex justify-content-between align-items-end mb-4 flex-wrap gap-2">
            <div>
                <span class="badge badge-soft">Sitios destacados</span>
                <h2 class="h3 fw-bold mt-2 mb-0">Lugares para explorar</h2>
            </div>

            <small class="text-muted">
                Se ordenan por calificación y actividad
            </small>
        </div>

        <div class="row g-4">

            <?php if ($destacados): ?>
                <?php foreach ($destacados as $sitio): ?>

                    <div class="col-md-6 col-lg-3">
    <div 
        class="card card-turismo h-100 shadow-sm sitio-card"
        style="cursor:pointer;"
        data-name="<?= e($sitio['name']) ?>"
        data-description="<?= e($sitio['description']) ?>"
        data-city="<?= e($sitio['city_name'] ?? '') ?>"
        data-department="<?= e($sitio['department_name'] ?? '') ?>"
        data-rating="<?= (float)$sitio['average_rating'] ?>"
        data-reviews="<?= (int)$sitio['rating_count'] ?>"
        data-cost="<?= $sitio['entry_cost'] ?>"
        data-currency="<?= e($sitio['currency_code']) ?>"
    >

        <div class="card-body d-flex flex-column">

            <div class="d-flex justify-content-between align-items-start mb-2">
                <h5 class="card-title mb-0">
                    <?= e($sitio['name']) ?>
                </h5>

                <span class="badge text-bg-warning">
                    <i class="fa-solid fa-star me-1"></i>
                    <?= number_format((float)$sitio['average_rating'], 1) ?>
                </span>
            </div>

            <p class="text-muted small mb-2">
                <?= e(trim(($sitio['city_name'] ?? '') . ' · ' . ($sitio['department_name'] ?? ''))) ?>
            </p>

            <p class="card-text text-muted flex-grow-1">
                <?= e(mb_strimwidth((string)$sitio['description'], 0, 110, '...')) ?>
            </p>

            <div class="d-flex justify-content-between align-items-center mt-2">
                <span class="small text-muted">
                    <i class="fa-solid fa-comment-dots me-1"></i>
                    <?= (int)$sitio['rating_count'] ?> valoraciones
                </span>

                <span class="fw-semibold text-orange">
                    <?= $sitio['entry_cost'] !== null
                        ? '$' . number_format((float)$sitio['entry_cost'], 0, ',', '.') . ' ' . e($sitio['currency_code'])
                        : 'Gratis'
                    ?>
                </span>
            </div>

        </div>

    </div>
</div>


                <?php endforeach; ?>

            <?php else: ?>

                <div class="col-12">
                    <div class="alert alert-info">
                        No hay sitios cargados todavía. Ejecuta el archivo de semillas de base de datos.
                    </div>
                </div>

            <?php endif; ?>

        </div>
    </div>
</section>

<script>
    window.turSegInfoPlaces = <?= $placesJson ?: '[]' ?>;
</script>

<!-- 🔥 MODAL (VA AQUÍ) -->
<div class="modal fade" id="modalSitio" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Información del sitio</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <p id="modalUbicacion" class="text-muted"></p>

        <p id="modalDescripcion"></p>

        <p>
          <strong>Precio:</strong>
          <span id="modalPrecio"></span>
        </p>

        <p>
          <strong>Calificación:</strong>
          ⭐ <span id="modalRating"></span>
          (<span id="modalCount"></span> opiniones)
        </p>

      </div>

    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
<?php
require_once __DIR__ . '/includes/functions.php';

// Si el usuario ya está logueado, lo mandamos directo a su panel
if (usuario_autenticado()) {
    redirect(es_admin() ? 'admin.php' : 'dashboard.php');
}

$errores = [];
$email = '';

if (is_post()) {
    verify_csrf();
    
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    
    // Validaciones básicas de entrada
    if (!validar_email($email)) {
        $errores[] = 'Ingresa un correo válido.';
    }
    if (strlen($password) < 6) {
        $errores[] = 'La contraseña debe tener al menos 6 caracteres.';
    }
    
    if (!$errores) {
        // Tu consulta estructurada (Mantenida a la perfección)
        $sql = "SELECT 
                    u.id, 
                    u.email, 
                    u.password_hash, 
                    u.status, 
                    u.role_id,
                    r.nombre_rol, 
                    p.display_name,
                    p.username
                FROM users u 
                INNER JOIN roles r ON r.id = u.role_id
                LEFT JOIN user_profiles p ON p.user_id = u.id 
                WHERE u.email = :email 
                LIMIT 1";
                
        $stmt = db()->prepare($sql);
        $stmt->execute(['email' => $email]);
        $usuario = $stmt->fetch();
        
        // Verificación de credenciales y estado de cuenta
        if (!$usuario || !password_verify($password, $usuario['password_hash'])) {
            $errores[] = 'Credenciales incorrectas.';
        } elseif ($usuario['status'] !== 'active') {
            // Te muestra en pantalla si la cuenta está pendiente, suspendida o eliminada para saber por qué no entra
            $errores[] = 'Tu cuenta no está activa. (Estado actual: ' . ucfirst($usuario['status']) . ').';
        } else {
            
            // CORRECCIÓN PRINCIPAL: Mapeamos explícitamente el array de sesión.
            // Así evitamos fallos si tus funciones globales buscan 'role' o 'nombre_rol'
            login_user([
                'id'           => (int)$usuario['id'],
                'email'        => $usuario['email'],
                'role'         => $usuario['nombre_rol'], // 'admin' o 'user'
                'nombre_rol'   => $usuario['nombre_rol'],
                'display_name' => $usuario['display_name'] ?? $usuario['username'] ?? 'Usuario',
                'username'     => $usuario['username']
            ]);
            
            set_flash('success', 'Inicio de sesión exitoso.');
            
            // Redirección limpia según el rol de la base de datos
            if ($usuario['nombre_rol'] === 'admin') {
                redirect('admin.php');
            } else {
                redirect('dashboard.php');
            }
        }
    }
}

$pageTitle = APP_NOMBRE . ' | Iniciar sesión';
require_once __DIR__ . '/includes/header.php';
?>

<section class="auth-section py-5">
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-8">
                <div class="card auth-card shadow-lg border-0">
                    <div class="card-body p-4 p-md-5">
                        
                        <h1 class="h3 fw-bold mb-2">Iniciar sesión</h1>
                        <p class="text-muted mb-4">Accede como usuario o administrador.</p>
                        
                        <?php if ($errores): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0 ps-3">
                                    <?php foreach ($errores as $error): ?>
                                        <li><?= e($error) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <form method="post" class="needs-validation" novalidate>
                            <?= csrf_field() ?>
                            
                            <div class="mb-3">
                                <label class="form-label">Correo electrónico</label>
                                <input type="email" name="email" class="form-control form-control-lg" value="<?= e($email) ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Contraseña</label>
                                <input type="password" name="password" class="form-control form-control-lg" minlength="6" required>
                            </div>
                            
                            <button class="btn btn-orange w-100 btn-lg" type="submit">Entrar</button>
                            
                            <div class="text-center mt-3">
                                <a href="<?= e(url('recover_contrasena.php')) ?>" class="text-orange text-decoration-none fw-bold small">
                                    ¿Olvidaste tu contraseña?
                                </a>
                            </div>
                        </form>
                        
                        <div class="mt-4 text-center border-top pt-3">
                            <small class="text-muted">
                                ¿No tienes cuenta? <a href="<?= e(url('register.php')) ?>" class="text-orange fw-bold text-decoration-none">Regístrate</a>
                            </small>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
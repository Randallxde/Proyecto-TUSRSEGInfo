<?php
// restablecer_contrasena.php
require_once __DIR__ . '/includes/functions.php';

if (usuario_autenticado()) {
    redirect(es_admin() ? 'admin.php' : 'dashboard.php');
}

$token = trim((string)($_GET['token'] ?? $_POST['token'] ?? ''));
$errores = [];

if (empty($token)) {
    set_flash('danger', 'Token inválido o ausente.');
    redirect('login.php');
}

$pdo = db();

$stmt = $pdo->prepare('SELECT email FROM password_resets WHERE token = :token AND expires_at > NOW()');
$stmt->execute(['token' => $token]);
$solicitud = $stmt->fetch();

if (!$solicitud) {
    set_flash('danger', 'El enlace ha expirado o es inválido. Solicita uno nuevo.');
    redirect('recuperar_contrasena.php');
}

$emailUsuario = $solicitud['email'];

if (is_post()) {
    verify_csrf();
    
    $password = (string)($_POST['password'] ?? '');
    $password2 = (string)($_POST['password_confirmation'] ?? '');
    
    if (strlen($password) < 6) {
        $errores[] = 'La contraseña debe tener al menos 6 caracteres.';
    }
    if ($password !== $password2) {
        $errores[] = 'Las contraseñas no coinciden.';
    }
    
    if (!$errores) {
        try {
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare('UPDATE users SET password_hash = :password_hash, updated_at = NOW() WHERE email = :email');
            $stmt->execute([
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'email' => $emailUsuario
            ]);
            
            $stmt = $pdo->prepare('DELETE FROM password_resets WHERE email = :email');
            $stmt->execute(['email' => $emailUsuario]);
            
            $pdo->commit();
            
            set_flash('success', 'Tu contraseña se ha cambiado correctamente. Ya puedes iniciar sesión.');
            redirect('login.php');
            
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $errores[] = 'No se pudo actualizar la contraseña en el sistema.';
        }
    }
}

$pageTitle = APP_NOMBRE . ' | Restablecer Contraseña';
require_once __DIR__ . '/includes/header.php';
?>

<section class="auth-section py-5">
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-5">
                <div class="card auth-card shadow-lg border-0">
                    <div class="card-body p-4 p-md-5">
                        <h1 class="h3 fw-bold mb-2">Nueva Contraseña</h1>
                        <p class="text-muted mb-4">Ingresa tu nueva clave para la cuenta: <strong><?= e($emailUsuario) ?></strong></p>
                        
                        <?php if ($errores): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0 ps-3">
                                    <?php foreach ($errores as $error): ?>
                                        <li><?= e($error) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <form method="post" class="needs-validation" novalidate>
                            <?= csrf_field() ?>
                            <input type="hidden" name="token" value="<?= e($token) ?>">
                            
                            <div class="mb-3">
                                <label class="form-label">Nueva Contraseña</label>
                                <input type="password" name="password" class="form-control form-control-lg" required minlength="6">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Confirmar Contraseña</label>
                                <input type="password" name="password_confirmation" class="form-control form-control-lg" required minlength="6">
                            </div>
                            <div class="d-grid gap-2 mt-4">
                                <button class="btn btn-orange btn-lg" type="submit">Cambiar contraseña</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
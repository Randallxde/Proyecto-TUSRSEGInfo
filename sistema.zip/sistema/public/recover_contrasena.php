<?php
// recuperar_contrasena.php
require_once __DIR__ . '/includes/functions.php';

if (usuario_autenticado()) {
    redirect(es_admin() ? 'admin.php' : 'dashboard.php');
}

$errores = [];
$email = '';

if (is_post()) {
    verify_csrf();
    
    $email = trim((string)($_POST['email'] ?? ''));
    
    if (!validar_email($email)) {
        $errores[] = 'El correo electrónico no es válido.';
    }
    
    if (!$errores) {
        $pdo = db();
        
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE email = :email');
        $stmt->execute(['email' => $email]);
        
        if ((int)$stmt->fetchColumn() > 0) {
            $token = bin2hex(random_bytes(32));
            $expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
try {
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare('DELETE FROM password_resets WHERE email = :email');
    $stmt->execute(['email' => $email]);
    
    $stmt = $pdo->prepare('INSERT INTO password_resets (email, token, expires_at) VALUES (:email, :token, :expires_at)');
    $stmt->execute([
        'email' => $email,
        'token' => $token,
        'expires_at' => $expiresAt
    ]);
    
    $pdo->commit();
    
    // 1. Corrige aquí el nombre de tu carpeta local (ej: TURSEG_INFO o como se llame en tu htdocs)
    $enlaceRecuperacion = "http://localhost/sistema/public/reset_contrasena.php?token=" . $token;
    
    // 2. ¡QUITA LAS DOS DIAGONALES DE ABAJO PARA MAPEAR EL ENLACE EN PANTALLA!
    die("<h3>[MODO PRUEBA LOCAL]</h3><p>El sistema envió este enlace:</p><a href='$enlaceRecuperacion'>$enlaceRecuperacion</a>");
    
} catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $errores[] = 'Hubo un error interno al procesar la solicitud.';
            }
        }
        
        set_flash('success', 'Si el correo está registrado, recibirás un enlace de recuperación en unos minutos.');
        redirect('login.php'); 
    }
}

$pageTitle = APP_NOMBRE . ' | Recuperar Contraseña';
require_once __DIR__ . '/includes/header.php'; 
?>

<section class="auth-section py-5">
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-5">
                <div class="card auth-card shadow-lg border-0">
                    <div class="card-body p-4 p-md-5">
                        <h1 class="h3 fw-bold mb-2">¿Olvidaste tu contraseña?</h1>
                        <p class="text-muted mb-4">Introduce tu correo y te enviaremos un enlace para restaurarla.</p>
                        
                        <?php if ($errores): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0 ps-3">
                                    <?php foreach ($errores as $error): ?>
                                        <li><?= e($error) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <form method="post" class="needs-validation" novalidate>
                            <?= csrf_field() ?>
                            <div class="mb-3">
                                <label class="form-label">Correo electrónico</label>
                                <input type="email" name="email" class="form-control form-control-lg" value="<?= e($email) ?>" required>
                            </div>
                            <div class="d-grid gap-2 mt-4">
                                <button class="btn btn-orange btn-lg" type="submit">Enviar enlace</button>
                                <a href="login.php" class="btn btn-link text-muted">Volver al login</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
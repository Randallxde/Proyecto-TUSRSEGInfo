TURSEGINFO - instalación rápida
1) Copia la carpeta del proyecto dentro de htdocs.
2) Importa turseginfo_db.sql en phpMyAdmin.
3) Ejecuta database/setup_extra.sql una sola vez.
4) Abre index.php desde el navegador.
5) Login admin de ejemplo:
   Email: admin@turseginfo.local
   Password: Admin1234!
Nota: el mapa usa Leaflet + OpenStreetMap para no depender de API keys.

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-06-2026 a las 17:34:13
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `turseginfo_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country_code` char(2) DEFAULT NULL,
  `department_name` varchar(80) DEFAULT NULL,
  `city_name` varchar(80) DEFAULT NULL,
  `dane_code` varchar(10) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cities`
--

INSERT INTO `cities` (`id`, `country_code`, `department_name`, `city_name`, `dane_code`, `created_at`) VALUES
(1, '1', 'Bogota', 'Bogota D.C.', '1', '2026-05-22 09:53:25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conversations`
--

CREATE TABLE `conversations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_by_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `last_message_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conversation_members`
--

CREATE TABLE `conversation_members` (
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `joined_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `current_locations`
--

CREATE TABLE `current_locations` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `geo_point` point DEFAULT NULL,
  `captured_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `friendships`
--

CREATE TABLE `friendships` (
  `user_low_id` bigint(20) UNSIGNED NOT NULL,
  `user_high_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `friend_requests`
--

CREATE TABLE `friend_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `requester_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `addressee_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('pending','accepted','rejected','cancelled') DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `location_groups`
--

CREATE TABLE `location_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `owner_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `status` enum('active','archived','deleted') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `location_group_members`
--

CREATE TABLE `location_group_members` (
  `group_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('active','left') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `media_assets`
--

CREATE TABLE `media_assets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `owner_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `storage_key` varchar(255) DEFAULT NULL,
  `storage_url` varchar(500) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `size_bytes` int(11) DEFAULT NULL,
  `width_px` int(11) DEFAULT NULL,
  `height_px` int(11) DEFAULT NULL,
  `checksum` char(64) DEFAULT NULL,
  `usage_scope` enum('avatar','place','message','other') DEFAULT NULL,
  `status` enum('pending','active','deleted','expired') DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `conversation_id` bigint(20) UNSIGNED DEFAULT NULL,
  `sender_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `body` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `moderation_reports`
--

CREATE TABLE `moderation_reports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `reporter_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `reported_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `reported_place_id` bigint(20) UNSIGNED DEFAULT NULL,
  `reported_comment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `report_reason` varchar(50) DEFAULT NULL,
  `status` enum('open','resolved','rejected') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `outbox_events`
--

CREATE TABLE `outbox_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `aggregate_type` varchar(50) DEFAULT NULL,
  `aggregate_id` bigint(20) UNSIGNED DEFAULT NULL,
  `event_type` varchar(80) DEFAULT NULL,
  `payload` longtext DEFAULT NULL,
  `status` enum('pending','processed') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(254) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `places`
--

CREATE TABLE `places` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `creator_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `city_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `geo_point` point DEFAULT NULL,
  `address_text` varchar(255) DEFAULT NULL,
  `cover_media_id` bigint(20) UNSIGNED DEFAULT NULL,
  `entry_cost` decimal(10,2) DEFAULT NULL,
  `currency_code` char(3) DEFAULT NULL,
  `rating_sum` decimal(10,2) DEFAULT 0.00,
  `rating_count` int(10) UNSIGNED DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `moderation_status` enum('pending','approved','flagged','rejected','hidden') DEFAULT 'pending',
  `status` enum('active','inactive','suspended','deleted') DEFAULT 'active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `places`
--

INSERT INTO `places` (`id`, `creator_user_id`, `city_id`, `name`, `description`, `geo_point`, `address_text`, `cover_media_id`, `entry_cost`, `currency_code`, `rating_sum`, `rating_count`, `average_rating`, `moderation_status`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 1, 'Museo del Oro', 'El museo de Bogotá', 0xe61000000101000000aa8251499d8452c04703780b24681240, 'Carrera 6 #15-88', NULL, 20.00, 'COP', 9.50, 0, 3.32, 'approved', 'active', '2026-05-22 10:11:38', '2026-06-03 10:47:01', NULL),
(2, 1, 1, 'Monserrate', 'El cerro de Monserrate es el ícono natural y religioso más emblemático de Bogotá. Elevado a 3.152 metros sobre el nivel del mar en los Cerros Orientales, ofrece la mejor vista panorámica de la ciudad. En su cima se encuentra el histórico santuario del Señor Caído, un importante centro de peregrinación.', 0x000000000101000000ffffffe98e8352c0023e38aafe6a1240, 'Carrera 2 Este No. 21-48', NULL, 0.00, 'COP', 0.00, 0, 0.00, 'approved', 'active', '2026-06-01 11:25:56', '2026-06-03 10:47:02', NULL),
(3, 2, 1, 'PARQUE ENTRE NUBES', 'muy bonito lugar', 0x000000000101000000eeffffe98b8652c015086d9a1d1e1240, 'hay una entrada al sur y otra en el norte', NULL, 0.00, 'COP', 0.00, 0, 0.00, 'approved', 'active', '2026-06-03 08:03:34', '2026-06-03 10:47:03', NULL),
(4, 9, 1, 'Plaza de Bolívar', 'La Plaza de Bolívar es la parada obligatoria número uno en Bogotá. Es el corazón histórico de Colombia y el lugar ideal para entender el pasado y el presente del país en un solo vistazo.', NULL, 'Para llegar a la plaza pueden ir a  la estacion de TransMilenio más cercanas a la Plaza de Bolívar que es Museo del Oro.', NULL, 0.00, 'COP', 0.00, 0, 4.50, 'approved', 'active', '2026-06-03 09:54:20', '2026-06-03 10:47:09', NULL),
(5, 9, 1, 'Parque de los Hippies', 'El Parque de los Hippies (cuyo nombre oficial es Parque Antonio José de Sucre) es el epicentro de la cultura alternativa, universitaria y diversa de Bogotá.', NULL, 'El Parque de los Hippies está ubicado en la Calle 60 con Carrera 7 (Chapinero). Aquí tienes las opciones clave para llegar:TransMilenio: Bájate en la Estación Calle 63 y camina tres cuadras hacia el oriente.Carro o Taxi: Llega por la Carrera 7 (sentido no', NULL, 0.00, 'COP', 0.00, 0, 0.00, 'approved', 'active', '2026-06-03 10:11:05', '2026-06-03 10:47:06', NULL),
(6, 9, 1, 'La Candelaria Centro Histórico', 'La Candelaria es el barrio más antiguo, artístico y mágico de Bogotá. Es el lugar donde se fundó la ciudad en 1538 y hoy funciona como un museo al aire libre, donde la arquitectura colonial española se mezcla con el arte urbano y la vibrante vida universitaria.', NULL, 'La localidad de La Candelaria se ubica en el centro de Bogotá (entre calles 6 y 19, de la carrera 10 hacia los cerros). Las formas clave de llegar son:TransMilenio: Bájate en las estaciones Museo del Oro, Las Aguas o Bicentenario.Vías principales (Carro/T', NULL, 0.00, 'COP', 0.00, 0, 0.00, 'approved', 'active', '2026-06-03 10:23:37', '2026-06-03 10:47:07', NULL),
(7, 9, 1, 'Parque de los Periodistas Gabriel García Márquez', 'El Parque de los Periodistas (oficialmente Parque de los Periodistas Gabriel García Márquez) es el punto exacto donde el centro histórico de La Candelaria se une con la Bogotá moderna [1]. Funciona como un dinámico umbral cultural y un punto de encuentro clave para estudiantes, intelectuales y viajeros.', 0x000000000101000000e5ffbf35738452c0f76292d9c0671240, 'El Parque de los Periodistas queda en la Carrera 3 con Avenida Jiménez. Se llega así:TransMilenio: Bájate en la Estación Las Aguas; queda dentro del parque.Carro o Taxi: Llega por la Calle 26 hacia el sur o sube por la Avenida Jiménez.A pie: Camina por el', NULL, 0.00, 'COP', 0.00, 0, 0.00, 'approved', 'active', '2026-06-03 10:31:52', '2026-06-03 10:46:58', NULL),
(8, 9, 1, 'Parque Marruecos', 'El Parque Marruecos (ubicado en la urbanización del mismo nombre) es un escenario principalmente de carácter vecinal, comunitario y recreodeportivo. A diferencia de los atractivos turísticos del centro de Bogotá o de Chapinero, este parque representa la vida cotidiana, el deporte barrial y la resiliencia comunitaria del sur de la ciudad.', NULL, 'El Parque Marruecos queda en el sur (Calle 49c Sur #5 T–18). Se llega así:TransMilenio: Bájate en Estación Molinos y toma el alimentador 4-1 (Bochica).SITP: Usa las rutas C101, H408 o L723 directo hasta el parque.Carro o Taxi: Sube por la Carrera 10 o la', NULL, 0.00, 'COP', 0.00, 0, 0.00, 'approved', 'active', '2026-06-03 10:36:10', '2026-06-03 10:46:57', NULL),
(9, 9, 1, 'Parque Simón Bolívar', 'El Parque Metropolitano Simón Bolívar es el \"pulmón verde\" de Bogotá y el parque urbano más importante de Colombia. Con un tamaño superior al de Central Park en Nueva York, es el epicentro de la recreación, el deporte y los megaeventos culturales de la capital.', NULL, 'El Parque Simón Bolívar está en el occidente (Calles 53 a 63, Carreras 60 a 68). Se llega así:TransMilenio: Bájate en Movistar Arena o El Tiempo - Cámara de Comercio y camina hacia el parque.SITP: Usa rutas por la Calle 63, Calle 53 o Carrera 68 que te de', NULL, 0.00, 'COP', 0.00, 0, 0.00, 'approved', 'active', '2026-06-03 10:38:57', '2026-06-03 10:46:57', NULL),
(10, 9, 1, 'Parque de los Periodistas Gabriel García Márquez', 'El Parque de los Periodistas (oficialmente Parque de los Periodistas Gabriel García Márquez) es el punto exacto donde el centro histórico de La Candelaria se une con la Bogotá moderna [1]. Funciona como un dinámico umbral cultural y un punto de encuentro clave para estudiantes, intelectuales y viajeros.', NULL, 'El Parque de los Periodistas queda en la Carrera 3 con Avenida Jiménez. Se llega así:TransMilenio: Bájate en la Estación Las Aguas; queda dentro del parque.Carro o Taxi: Llega por la Calle 26 hacia el sur o sube por la Avenida Jiménez.A pie: Camina por el', NULL, 0.00, 'COP', 0.00, 0, 0.00, 'approved', 'active', '2026-06-03 10:31:52', '2026-06-03 10:46:58', NULL),
(11, 9, 1, 'Parque de los Novios', 'El Parque de los Novios (cuyo nombre oficial es Parque Metropolitano El Lago) es uno de los espacios más acogedores y románticos de Bogotá. Con una extensión de 23 hectáreas, este oasis natural en la localidad de Barrios Unidos es famoso por su ambiente tranquilo, ideal para parejas, familias y entusiastas de los picnics.', 0x0000000001010000000600c055438552c0f066050e009d1240, 'El Parque de los Novios queda en la Calle 63 # 45 - 10 (Barrios Unidos). Se llega así:TransMilenio: Bájate en Movistar Arena y camina dos cuadras hacia el occidente.SITP: Usa rutas por la Calle 63 que paran frente a la entrada principal.Carro o Taxi: Lleg', NULL, 0.00, 'COP', 0.00, 0, 0.00, 'approved', 'active', '2026-06-03 10:42:35', '2026-06-03 10:46:56', NULL),
(12, 9, 1, 'El Museo del Oro', 'El Museo del Oro del Banco de la República es el centro cultural más emblemático de Bogotá y una joya imprescindible para cualquier visitante. Custodia la colección de orfebrería prehispánica más grande del mundo, con más de 34.000 piezas de oro y miles de objetos de cerámica y piedra de las culturas indígenas colombianas.', 0x000000000101000000e8ff7f7c998452c03305102f2e681240, 'El Museo del Oro queda en el centro histórico, en la Carrera 6 # 15 - 88 (frente el Parque Santander). Se llega así:TransMilenio: Bájate en la Estación Museo del Oro (Eje Ambiental) o camina desde la Estación Calle 19 (Troncal Caracas).SITP / Bus: Toma ru', NULL, 0.00, 'COP', 0.00, 0, 0.00, 'approved', 'active', '2026-06-03 10:45:52', '2026-06-03 10:46:46', NULL);
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `place_comments`
--

CREATE TABLE `place_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `place_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `parent_comment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `body` text DEFAULT NULL,
  `moderation_status` enum('pending','approved','hidden','removed') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `place_comments`
--

INSERT INTO `place_comments` (`id`, `place_id`, `user_id`, `parent_comment_id`, `body`, `moderation_status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 2, NULL, 'que bonito museo', 'approved', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `place_ratings`
--

CREATE TABLE `place_ratings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `place_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `rating` tinyint(3) UNSIGNED DEFAULT NULL,
  `review_text` text DEFAULT NULL,
  `status` enum('visible','hidden','removed') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre_rol` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `nombre_rol`, `descripcion`, `created_at`) VALUES
(1, 'admin', 'Administrador de la plataforma, acceso al panel de gestión y moderación', '2026-05-21 19:23:30'),
(2, 'user', 'Usuario estándar de la aplicación, turista o ciudadano', '2026-05-21 19:23:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED DEFAULT 2,
  `email` varchar(254) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `status` enum('pending','active','suspended') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `role_id`, `email`, `password_hash`, `date_of_birth`, `email_verified_at`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'luis_feliciano@soy.sena.edu.co', '$2y$10$qMDAkbOH7FIw/zZ2KKOcEuU.9xt.rTfYltYpCLhpiLm/t3T9TOYie', '2009-04-13', '2026-05-21 20:03:20', 'active', '2026-05-21 20:03:20', '2026-06-03 10:31:34', NULL),
(2, 1, 'ale@soy.sena.edu.co', '$2y$10$w7gh9U5IyPGsUhqRRDePS.mGtIZN9K1EtPFAX7MIyXqugrA1WYxxy', '2009-03-17', '2026-05-22 07:36:57', 'active', '2026-05-22 07:36:57', '2026-06-01 06:42:47', NULL),
(3, 1, 'julian@soy.sena.edu.co', '$2y$10$soXZJq.t7DxrptegBiAhQ.K/nJ8cqxBPIZpbSE1lmBhdmorWfmE1m', '2009-03-03', '2026-05-22 09:13:31', 'active', '2026-05-22 09:13:31', '2026-06-01 09:41:43', NULL),
(4, 1, 'ran@soy.sena.edu.co', '$2y$10$HEbDOzSJRj73CqWYepajouz34RT.b12CBkkKD4JaS8SCC.yKwBGhu', '2008-02-05', '2026-05-28 08:02:22', 'active', '2026-05-28 08:02:22', '2026-06-03 10:23:02', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_profiles`
--

CREATE TABLE `user_profiles` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `display_name` varchar(80) DEFAULT NULL,
  `bio` varchar(280) DEFAULT NULL,
  `avatar_media_id` varchar(255) DEFAULT NULL,
  `profile_visibility` enum('public','friends','private') DEFAULT 'public',
  `location_visibility` enum('public','friends','private') DEFAULT 'friends',
  `show_age` tinyint(1) DEFAULT 1,
  `city_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `user_profiles`
--

INSERT INTO `user_profiles` (`user_id`, `username`, `display_name`, `bio`, `avatar_media_id`, `profile_visibility`, `location_visibility`, `show_age`, `city_id`, `created_at`, `updated_at`) VALUES
(1, 'rocky', 'luis feliciano', NULL, 'public/img/cfcceb47a753dd32205a306f25bc561c.png', 'public', 'friends', 0, NULL, '2026-05-21 20:03:20', '2026-06-03 10:22:00'),
(2, 'alejandro', 'ale', NULL, 'public/img/8e3c87da618969c70a520c22144d9a1c.png', 'public', 'friends', 0, NULL, '2026-05-22 07:36:57', '2026-06-03 08:22:07'),
(3, 'julian', 'julian', NULL, 'public/img/24e25f8996f3c5c2f75fb91157c47339.png', 'public', 'friends', 0, NULL, '2026-05-22 09:13:31', '2026-06-01 09:41:43'),
(4, 'RANDALL', 'Randall', NULL, '8fd0733c67cb.png', 'public', 'friends', 0, NULL, '2026-05-28 08:02:22', '2026-05-28 08:02:22');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `conversations`
--
ALTER TABLE `conversations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by_user_id` (`created_by_user_id`);

--
-- Indices de la tabla `conversation_members`
--
ALTER TABLE `conversation_members`
  ADD PRIMARY KEY (`conversation_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `current_locations`
--
ALTER TABLE `current_locations`
  ADD PRIMARY KEY (`user_id`);

--
-- Indices de la tabla `friendships`
--
ALTER TABLE `friendships`
  ADD PRIMARY KEY (`user_low_id`,`user_high_id`),
  ADD KEY `user_high_id` (`user_high_id`);

--
-- Indices de la tabla `friend_requests`
--
ALTER TABLE `friend_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requester_user_id` (`requester_user_id`),
  ADD KEY `addressee_user_id` (`addressee_user_id`);

--
-- Indices de la tabla `location_groups`
--
ALTER TABLE `location_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `owner_user_id` (`owner_user_id`);

--
-- Indices de la tabla `location_group_members`
--
ALTER TABLE `location_group_members`
  ADD PRIMARY KEY (`group_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `media_assets`
--
ALTER TABLE `media_assets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `owner_user_id` (`owner_user_id`);

--
-- Indices de la tabla `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `conversation_id` (`conversation_id`),
  ADD KEY `sender_user_id` (`sender_user_id`);

--
-- Indices de la tabla `moderation_reports`
--
ALTER TABLE `moderation_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reporter_user_id` (`reporter_user_id`);

--
-- Indices de la tabla `outbox_events`
--
ALTER TABLE `outbox_events`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `email` (`email`);

--
-- Indices de la tabla `places`
--
ALTER TABLE `places`
  ADD PRIMARY KEY (`id`),
  ADD KEY `creator_user_id` (`creator_user_id`),
  ADD KEY `city_id` (`city_id`);

--
-- Indices de la tabla `place_comments`
--
ALTER TABLE `place_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `place_id` (`place_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `place_ratings`
--
ALTER TABLE `place_ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `place_id` (`place_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre_rol` (`nombre_rol`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role_id` (`role_id`);

--
-- Indices de la tabla `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `city_id` (`city_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `conversations`
--
ALTER TABLE `conversations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `friend_requests`
--
ALTER TABLE `friend_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `location_groups`
--
ALTER TABLE `location_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `media_assets`
--
ALTER TABLE `media_assets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `moderation_reports`
--
ALTER TABLE `moderation_reports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `outbox_events`
--
ALTER TABLE `outbox_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `places`
--
ALTER TABLE `places`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `place_comments`
--
ALTER TABLE `place_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `place_ratings`
--
ALTER TABLE `place_ratings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `conversations`
--
ALTER TABLE `conversations`
  ADD CONSTRAINT `conversations_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `conversation_members`
--
ALTER TABLE `conversation_members`
  ADD CONSTRAINT `conversation_members_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`),
  ADD CONSTRAINT `conversation_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `current_locations`
--
ALTER TABLE `current_locations`
  ADD CONSTRAINT `current_locations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `friendships`
--
ALTER TABLE `friendships`
  ADD CONSTRAINT `friendships_ibfk_1` FOREIGN KEY (`user_low_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `friendships_ibfk_2` FOREIGN KEY (`user_high_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `friend_requests`
--
ALTER TABLE `friend_requests`
  ADD CONSTRAINT `friend_requests_ibfk_1` FOREIGN KEY (`requester_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `friend_requests_ibfk_2` FOREIGN KEY (`addressee_user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `location_groups`
--
ALTER TABLE `location_groups`
  ADD CONSTRAINT `location_groups_ibfk_1` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `location_group_members`
--
ALTER TABLE `location_group_members`
  ADD CONSTRAINT `location_group_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `location_groups` (`id`),
  ADD CONSTRAINT `location_group_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `media_assets`
--
ALTER TABLE `media_assets`
  ADD CONSTRAINT `media_assets_ibfk_1` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`sender_user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `moderation_reports`
--
ALTER TABLE `moderation_reports`
  ADD CONSTRAINT `moderation_reports_ibfk_1` FOREIGN KEY (`reporter_user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`email`) REFERENCES `users` (`email`) ON DELETE CASCADE;

--
-- Filtros para la tabla `places`
--
ALTER TABLE `places`
  ADD CONSTRAINT `places_ibfk_1` FOREIGN KEY (`creator_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `places_ibfk_2` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`);

--
-- Filtros para la tabla `place_comments`
--
ALTER TABLE `place_comments`
  ADD CONSTRAINT `place_comments_ibfk_1` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`),
  ADD CONSTRAINT `place_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `place_ratings`
--
ALTER TABLE `place_ratings`
  ADD CONSTRAINT `place_ratings_ibfk_1` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`),
  ADD CONSTRAINT `place_ratings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `user_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `user_profiles_ibfk_2` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
